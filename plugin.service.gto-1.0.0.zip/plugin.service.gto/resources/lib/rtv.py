#!/usr/bin/python

import re

class rtvScraper():

    def __init__(self):

        # Items

        self.channel = ''
        self.title = ''
        self.thumb = ''
        self.detailURL = ''
        self.starttime = ''
        self.runtime = '0'
        self.genre = ''
        self.extrainfos = ''
        self.cast = ''

        self.endtime = ''

    def scrapeRSS(self, content):

        try:
            self.channel = re.compile('<description>(.+?),', re.DOTALL).findall(content)[0]
            # self.thumb = re.compile('<media:content url="(.+?)" type="image/jpeg"/>', re.DOTALL).findall(content)[0]
            self.detailURL = re.compile('<link>(.+?)</link>', re.DOTALL).findall(content)[0]
            self.title = ', '.join(re.compile('<title>(.+?)</title>', re.DOTALL).findall(content)[0].split(' - ')[:-1])
        except IndexError:
            pass

        try:
            self.extrainfos = re.compile('<description>(.+?)</description>', re.DOTALL).findall(content)[0].split('&lt;br/&gt;&lt;br/&gt;')[1]
            self.genre = re.compile('Uhr&lt;br/&gt;(.+?),', re.DOTALL).findall(content)[0]
            self.cast = re.compile('<description>(.+?)</description>', re.DOTALL).findall(content)[0].split('&lt;br/&gt;&lt;br/&gt;')[2][5:]
        except IndexError:
            pass

        try:
            self.date = re.compile('<title>(.+?)</title>', re.DOTALL).findall(content)[0].split(',')[-2].strip()
            self.starttime = re.compile('<title>(.+?)</title>', re.DOTALL).findall(content)[0].split(',')[-1].strip().replace(' Uhr', '')
        except IndexError:
            pass

    def scrapeDetailPage(self, content, contentID):

        if contentID in content:

            container = content.split(contentID)
            container.pop(0)
            content = container[0]

            # Thumbnail
            try:
                self.thumb = re.compile('style="background-image:(.+?);">', re.DOTALL).findall(content)[0].split("'")[1]
            except IndexError:
                try:
                    self.thumb = re.compile('<img class="kalooga_12730" src="(.+?)"', re.DOTALL).findall(content)[0]
                except IndexError:
                    pass

            # Broadcast Info (stop)
            try:
                self.endtime = re.compile('<div class="time">(.+?)</div>', re.DOTALL).findall(content)[0].split()[2]
            except IndexError:
                pass


