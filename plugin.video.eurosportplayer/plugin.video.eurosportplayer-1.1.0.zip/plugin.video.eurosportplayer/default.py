# -*- coding: utf-8 -*-

import os,sys,urllib,urlparse
import xbmc,xbmcaddon,xbmcgui,xbmcplugin

addon = xbmcaddon.Addon()
home = addon.getAddonInfo('path').decode('utf-8')
iconimage = xbmc.translatePath(os.path.join(home, 'icon.png'))
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
pluginhandle = int(sys.argv[1])

from resources.lib.client import Client
from resources.lib import helper
from resources.lib import cache

def channels():
    data = Client().get_products()
    if data:
        items = helper.get_channel_items(data)
        for i in items:
            add_video(i)
        add_dir({'mode':'sports', 'title':'Videos', 'description':'Video On Demand'})
    xbmcplugin.setContent(pluginhandle, 'episodes')
    xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=False)

def sports():
    data = Client().get_catchups()
    if data:
        cache.cache_data(data)
        items = helper.get_sport_items(data)
        for i in items:
            add_dir(i)
    xbmcplugin.setContent(pluginhandle, 'episodes')
    xbmcplugin.endOfDirectory(pluginhandle)
    
def videos():
    id = args['id'][0]
    data = cache.get_cache_data()
    if data:
        items = helper.get_video_items(data,id)
        for i in items:
            add_video(i)
    xbmcplugin.setContent(pluginhandle, 'episodes')
    xbmcplugin.endOfDirectory(pluginhandle)
    
def play_live():
    id = args['id'][0]
    index = select_index(id)
    spl = id.split('?')
    if len(spl) == 2:
        token = spl[1]
        path = helper.add_param(index,token)
    else:
        path = index
    listitem = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def play_video():
    id = args['id'][0]
    if 'm3u8' in id:
        path = get_path(id)
    else:
        path = id
    listitem = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def get_path(id):
    data = Client().get_token()
    if data:
        token = helper.get_token(data)
        master = helper.add_param(id,token)
        index = select_index(master)
        path = helper.add_param(index,token)
        return path
    return id

def select_index(master):
    q = int(addon.getSetting('quality'))
    data = Client().get_data(master)
    if data:
        index = helper.get_index(data,q)
        if index:
            return index
    return master
    
def add_dir(item):
    u = build_url({'mode':item['mode'], 'title':item['title'], 'id':item.get('id','')})
    li=xbmcgui.ListItem(item['title'])
    li.setInfo(type='Video', infoLabels={'Title':item['title'], 'Plot':item.get('description', '')})
    li.setArt({'thumb': item.get('image', iconimage), 'fanart': fanart})
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=li,isFolder=True)

def add_video(item):
    u = build_url({'mode': item['mode'], 'title':item['title'], 'id':item['id']})
    li=xbmcgui.ListItem(item['title'])
    li.setArt({'thumb': item['image'], 'fanart': fanart})
    li.setInfo(type='Video', infoLabels={'Title':item['title'], 'Plot':item['description'], 'premiered':item['date'], 'Episode':item['episode']})
    li.addStreamInfo('video', {'duration':item['duration']})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=li)
    
def credentials():
    email    = addon.getSetting('email')
    password = addon.getSetting('password')
    if email and password:
        return True
    else:
        return False

def build_url(query):
    return sys.argv[0] + '?' + urllib.urlencode(query)

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
xbmc.log('[eurosportplayer] arguments: %s' % (str(args)), xbmc.LOGNOTICE)

if mode==None:
    if credentials():
        channels()
    else:
        addon.openSettings()
else:
    exec '%s()' % mode[0]