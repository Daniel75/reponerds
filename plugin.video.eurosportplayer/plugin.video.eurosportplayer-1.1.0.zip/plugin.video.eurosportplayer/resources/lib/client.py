# -*- coding: utf-8 -*-

import simple_requests as requests
import xbmc, xbmcaddon, urllib, json, re, time
addon = xbmcaddon.Addon()

class Client(object):

    def __init__(self):
    
        self.base_url   = 'http://www.eurosportplayer.com'
    
        self.headers    = {
                            'User-Agent':  'Kodi',
                            'Referer'   :  self.base_url
                            }
        
        self.CRM_URL    = 'https://playercrm.ssl.eurosport.com/JsonPlayerCrmApi.svc/'
        self.CRM_LOGIN  = self.CRM_URL + 'Login'

        self.VS_URL         = 'http://videoshop.ext.eurosport.com/JsonProductService.svc/'
        self.VIDEO_PRODUCTS = self.VS_URL + 'GetAllProductsByDeviceMobile'
        self.VIDEO_CATCHUPS = self.VS_URL + 'GetAllCatchupCache'
        self.VIDEO_TOKEN    = self.VS_URL + 'GetToken'

        self.login_data = {'email':'', 'password':'', 'udid':'00000000-0000-0000-0000-000000000000'}
        self.context    = {'g':'', 'd':'2', 's':'1', 'p':'1', 'b':'Kodi'}
        self.dvs        = {'userid':'', 'hkey':'', 'languageid':'', 'isbroadcasted':'1', 'isfullaccess':'0'}
        
        self.set_user_data()
        
    def set_user_data(self):
        
        self.set_location()
        
        self.login_data['email']    = addon.getSetting('email').encode('utf-8')
        self.login_data['password'] = addon.getSetting('password').encode('utf-8')
    
        self.dvs['userid']      = addon.getSetting('userid')
        self.dvs['hkey']        = addon.getSetting('hkey')

    def set_location(self):
    
        data = self.get_data(self.base_url)
        
        c = re.search("crmlanguageid:'(\d+)'", data)
        if c:
            self.dvs['languageid'] = c.group(1)
            
        g = re.search("geoloc:'(\w+)'", data)
        if g:
            self.context['g'] = g.group(1)

    def set_user_ref(self):
    
        user_ref = self.ep_login()
        xbmc.log('[eurosportplayer] login: %s' % (user_ref['Response']['Message'].encode('utf-8')), xbmc.LOGNOTICE)
        
        if user_ref.get('Id', '') and user_ref.get('Hkey', ''):
        
            self.dvs['userid'] = user_ref['Id']
            addon.setSetting('userid', user_ref['Id'])
            
            self.dvs['hkey'] = user_ref['Hkey']
            addon.setSetting('hkey', user_ref['Hkey'])
    
    def get_products(self):
        
        def get_json():
        
            result = {'ActiveUserRef': {'Response': {'Message': 'Products Request Failed'}}}
            
            try:
                encoded = urllib.urlencode({'data': json.dumps(self.dvs), 'context' : json.dumps(self.context)})
                channelsUrl = self.VIDEO_PRODUCTS + '?' + encoded
                data = requests.get(channelsUrl, headers=self.headers).json()
                return data
            except:
                pass
                
            return result
        
        data = get_json()
        if not 'success' in data['ActiveUserRef']['Response']['Message']:
            xbmc.log('[eurosportplayer] : %s' % (data['ActiveUserRef']['Response']['Message'].encode('utf-8')), xbmc.LOGNOTICE)
            self.set_user_ref()
            data = get_json()
            
        return data

    def get_catchups(self):
    
        encoded = urllib.urlencode({'data': json.dumps(self.dvs), 'context' : json.dumps(self.context)})
        videosUrl = self.VIDEO_CATCHUPS + '?' + encoded
        
        result = {}
        
        try:
            data = requests.get(videosUrl, headers=self.headers).json()
            return data
        except:
            pass
            
        return result
        
    def ep_login(self):
    
        encodedData = urllib.urlencode({'data': json.dumps(self.login_data), 'context' : json.dumps(self.context)})
        loginUrl = self.CRM_LOGIN + '?' + encodedData
        
        result = {'Response': {'Message': 'Login Request Failed'}}
        
        try:
            data = requests.get(loginUrl, headers=self.headers).json()
            return data
        except:
            pass
            
        return result
    
    def get_token(self):
    
        encoded = urllib.urlencode({'data': json.dumps(self.dvs), 'context' : json.dumps(self.context)})
        tokenUrl = self.VIDEO_TOKEN + '?' + encoded
        
        result = {}
        
        try:
            data = requests.get(tokenUrl, headers=self.headers).json()
            return data
        except:
            pass
            
        return result
        
    def get_data(self, url):
    
        result = ''
        
        try:
            data = requests.get(url, headers=self.headers, allow_redirects=True).text
            return data
        except:
            pass
            
        return result
        
    def cache(self):
    
        now = time.time()
        cache_time = addon.getSetting('cache_time')

        if cache_time:
            if (now - int(float(cache_time))) < (24*3600):
                return True
                
        return False