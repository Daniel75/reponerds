# -*- coding: utf-8 -*-

import datetime, re

def get_channel_items(data):
    items = []
    obj = data.get('PlayerObj', None)
    if obj:
        for i in obj:
            live = None
            s = None
            label = ''
            sublabel = ''
            label = i['channellivelabel']
            sublabel = i['channellivesublabel']
            plot = sublabel
            livestreams = i['livestreams'][0]
            id = livestreams['url']
            audio = livestreams['audio']
            vignetteurl = i['vignetteurl']
            u = 'http://i.eurosportplayer.com/'
            image = u+vignetteurl
            
            if i['tvscheduleliveevents']:
                s = find_current_show(i['tvscheduleliveevents'])
            elif i['tvschedules']:
                s = find_current_show(i['tvschedules'])
                if s:
                    sublabel = s.get('name', '')
                    if not sublabel:
                        sublabel = i['channellivesublabel']
            if not sublabel:
                sublabel = livestreams['name']
                sublabel = re.sub('(  .+?)$', '', sublabel)
                live = 1
            if s:
                if not live == 1:
                    live = s.get('transmissiontypeid', 0)
                name = s['name']
                description = s['description']
                duration = s['duration']
                startdate = s['startdate']
                sdate = startdate['technicaldate']
                stime = startdate['time']
                enddate = s['enddate']
                edate = enddate['technicaldate']
                etime = enddate['time']
                plot = unicode('%s (%s)\n%s\nStart: %s %s\nEnd: %s %s' % (name,audio,description,sdate,stime,edate,etime)).encode('utf-8')
            if live == 1:
                title = unicode('%s [COLOR red]LIVE[/COLOR] [I]%s[/I]' % (label,sublabel)).encode('utf-8')
            else:
                title = unicode('%s [I]%s[/I]' % (label,sublabel)).encode('utf-8')
                
            plot = re.sub('<.+?>', ' ', plot)
            title = re.sub('<.+?>', ' ', title)
                
            items.append({  'mode':'play_live',
                            'title':title, 
                            'id':id, 
                            'description':plot, 
                            'image':image, 
                            'duration':0,
                            'episode':0,
                            'date':0
                            })
    return items

def find_current_show(tvschedules):
    now = datetime.datetime.now()
    for s in tvschedules:
        endtime = convert_date(s['enddate']['datetime'])
        starttime = convert_date(s['startdate']['datetime'])
        if now < endtime and now >= starttime:
            return s
    return None

def convert_date(dateString):
    date_regex = re.compile('Date\(([0-9]*?)\+([0-9]*?)\)')
    r = date_regex.search(dateString)
    (time, offset) = r.groups()
    time = int(time)
    time = time / 1000
    return datetime.datetime.fromtimestamp(time)

def get_sport_items(data):
    items = []
    obj = data['PlayerObj']
    if obj:
        u = 'http://i.eurosportplayer.com'
        sports = obj['sports']
        for i in sports:
            title = i['name'].encode('utf-8')
            id = i['id']
            pictureurl = i['pictureurl'].replace(' ', '%20')
            if not pictureurl.startswith('http'):
                image = u+pictureurl
            else:
                image = pictureurl
            items.append({  'mode':'videos',
                            'title':title, 
                            'id':id, 
                            'image':image
                            })
    return items
    
def get_video_items(data,match):
    items = []
    catchups = data['PlayerObj']['catchups']
    for i in catchups:
        episode = i['idcatchup']
        sport = i['sport']['name']
        sportid = i['sport']['id']
        title = i['titlecatchup'].strip().encode('utf-8')
        id = i['catchupstreams'][0]['url']
        description = i['description']
        if description:
            description = description.encode('utf-8')
        image = i['pictureurl']+'|User-Agent=Android'
        duration = i['durationInSeconds']
        date = i['startdate']['technicaldate']
        if str(match) == str(sportid):
            items.append({  'mode':'play_video', 
                            'title':title, 
                            'id':id, 
                            'duration':duration, 
                            'description':description, 
                            'image':image,
                            'episode':episode,
                            'date':date
                            })
    return items

def get_token(data):
    token = ''
    try:
        o = data['PlayerObj']
        token = o['token']
    except:
        pass
    return token

def get_index(data,q):
    y = [600000,1200000,2400000,4800000]
    z = y[q]
    result = None
    list = []
    pattern = 'bandwidth=(\d+).*?\n(http.*?)$'
    match = re.findall(pattern, data, re.I|re.M)
    if match:
        for b,u in match:
            list.append({'bandwidth':int(b), 'url':u})
    if list:
        list = sorted(list, key=lambda k:k['bandwidth'])
        for x in list:
            if x['bandwidth'] < z:
                index = x['url']
            else:
                break
        return index
    return result
    
def add_param(url,param):
    if '?' in url:
        url = '%s&%s' % (url,param)
    else:
        url = '%s?%s' % (url,param)
    return url