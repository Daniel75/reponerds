# -*- coding: utf-8 -*-

import json,os,sys,urllib,urlparse
import xbmc,xbmcaddon,xbmcgui,xbmcplugin

addon = xbmcaddon.Addon()
home = addon.getAddonInfo('path').decode('utf-8')
iconimage = xbmc.translatePath(os.path.join(home, 'icon.png'))
pluginhandle = int(sys.argv[1])

from resources.lib.client import Client
from resources.lib import helper
from resources.lib import cache

def channels():
    data = Client().get_products()
    if data:
        items = helper.get_channel_items(data)
        for i in items:
            add_video(i)
        add_dir({'mode':'sports', 'title':'Videos'})
    #xbmcplugin.setContent(pluginhandle, 'episodes')
    xbmcplugin.endOfDirectory(pluginhandle, cacheToDisc=False)

def sports():
    data = Client().get_catchups()
    if data:
        cache.cache_data(data)
        items = helper.get_sport_items(data)
        for i in items:
            add_dir(i)
    xbmcplugin.endOfDirectory(pluginhandle)
    
def videos():
    id = args['id'][0]
    data = cache.get_cache_data()
    if data:
        items = helper.get_video_items(data,id)
        for i in items:
            add_video(i)
    xbmcplugin.endOfDirectory(pluginhandle)
    
def play():
    id = args['id'][0]
    index = select_index(id)
    spl = id.split('?')
    if len(spl) == 2:
        params = spl[1]
        if '?' in index:
            path = '%s&%s' % (index,params)
        else:
            path = '%s?%s' % (index,params)
    else:
        path = index
    listitem = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def play_video():
    id = args['id'][0]
    if 'm3u8' in id:
        path = get_path(id)
    else:
        path = id
    listitem = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)

def get_path(id):
    data = Client().get_token()
    if data:
        token = helper.get_token(data)
        if '?' in id:
            master = '%s&%s' % (id,token)
        else:
            master = '%s?%s' % (id,token)
        index = select_index(master)
        if not 'token' in index or not 'hdnea' in index:
            if '?' in index:
                path = '%s&%s' % (index,token)
            else:
                path = '%s?%s' % (index,token)
        else:
            path = index
        return path
    return id

def select_index(master):
    q = int(addon.getSetting('quality'))
    data = Client().get_data(master)
    if data:
        index = helper.get_index(data,q)
        if index:
            return index
    return master
    
def add_dir(item):
    u = build_url({'mode':item['mode'], 'title':item['title'], 'id':item.get('id','')})
    item=xbmcgui.ListItem(item['title'], iconImage="DefaultFolder.png", thumbnailImage=item.get('image', iconimage))
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item,isFolder=True)

def add_video(item):
    title = item['title']
    id = item['id']
    image = item.get('image', '')
    plot = item.get('description', '')
    duration = item.get('duration', '')
    date = item.get('date', '')
    u = build_url({'mode': item['mode'], 'title':title, 'id':id})
    item=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=image)
    item.setInfo(type='Video', infoLabels={'Title':title, 'Plot':plot})
    item.addStreamInfo('video', {'duration':duration})
    item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item)
    
def credentials():
    email    = addon.getSetting('email')
    password = addon.getSetting('password')
    if email and password:
        return True
    else:
        return False

def build_url(query):
    return sys.argv[0] + '?' + urllib.urlencode(query)

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
xbmc.log('[eurosportplayer] arguments: %s' % (str(args)), level=xbmc.LOGDEBUG)

if mode==None:
    if credentials():
        channels()
    else:
        addon.openSettings()
else:
    exec '%s()' % mode[0]