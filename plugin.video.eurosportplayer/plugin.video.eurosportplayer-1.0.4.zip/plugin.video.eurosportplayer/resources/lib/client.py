# -*- coding: utf-8 -*-

import simple_requests as requests
import xbmc, xbmcaddon, urllib, json, re
addon = xbmcaddon.Addon()

class Client(object):

    def __init__(self):
    
        self.base_url   = 'http://www.eurosportplayer.com'
    
        self.headers    = {
                            'User-Agent':  'Kodi',
                            'Referer'   :  self.base_url
                            }
        
        email    = addon.getSetting('email').encode('utf-8')
        password = addon.getSetting('password').encode('utf-8')
        
        self.CRM_URL    = 'https://playercrm.ssl.eurosport.com/JsonPlayerCrmApi.svc/'
        self.CRM_LOGIN  = self.CRM_URL + 'Login'
        self.CRM_UNLINK = self.CRM_URL + 'Unlink'

        self.VS_URL         = 'http://videoshop.ext.eurosport.com/JsonProductService.svc/'
        self.VIDEO_PRODUCTS = self.VS_URL + 'GetAllProductsByDeviceMobile'
        self.VIDEO_CATCHUPS = self.VS_URL + 'GetAllCatchupCache'
        self.VIDEO_TOKEN    = self.VS_URL + 'GetToken'

        self.login_data = {'email':email, 'password':password, 'udid':'00000000-0000-0000-0000-000000000000'}
        self.context    = {'g':'', 'd':'2', 's':'1', 'p':'1', 'b':'Kodi'}
        self.dvs        = {'userid':'', 'hkey':'', 'languageid':'', 'isbroadcasted':'1', 'isfullaccess':'0'}
        
        self.set_location()
        
    def set_location(self):
        try:
            data = self.get_data(self.base_url)
            c = re.search("crmlanguageid:'(\d+)'", data).group(1)
            self.dvs['languageid'] = c
            g = re.search("geoloc:'(\w+)'", data).group(1)
            self.context['g'] = g
        except:
            pass

    def get_dvs_context(self, user_ref):
        if user_ref:
            try:
                self.dvs['userid'] = user_ref['Id']
                addon.setSetting('userid', user_ref['Id'])
                self.dvs['hkey'] = user_ref['Hkey']
                addon.setSetting('hkey', user_ref['Hkey'])
            except KeyError:
                pass
        else:
            try:
                self.dvs['userid'] = addon.getSetting('userid')
                self.dvs['hkey'] = addon.getSetting('hkey')
            except:
                pass

        return (self.dvs, self.context)
    
    def get_products(self):
        user_ref = self.ep_login()
        xbmc.log('[eurosportplayer] login: %s' % (user_ref['Response']['Message'].encode('utf-8')), level=xbmc.LOGDEBUG)
        (d, c) = self.get_dvs_context(user_ref)
        encoded = urllib.urlencode({'data': json.dumps(d), 'context' : json.dumps(c)})
        channelsUrl = self.VIDEO_PRODUCTS + '?' + encoded
        
        result = {}
        try:
            data = requests.get(channelsUrl, headers=self.headers).json()
            return data
        except:
            pass
        return result

    def get_catchups(self):
        (d, c) = self.get_dvs_context(user_ref=False)
        encoded = urllib.urlencode({'data': json.dumps(d), 'context' : json.dumps(c)})
        videosUrl = self.VIDEO_CATCHUPS + '?' + encoded
        result = {}
        try:
            data = requests.get(videosUrl, headers=self.headers).json()
            return data
        except:
            pass
        return result
        
    def ep_login(self):
        result = {'Response': {'Message': 'Login Request Failed'}}
        try:
            encodedData = urllib.urlencode({'data': json.dumps(self.login_data), 'context' : json.dumps(self.context)})
            loginUrl = self.CRM_LOGIN + '?' + encodedData
            data = requests.get(loginUrl, headers=self.headers).json()
            return data
        except:
            pass
        return result
    
    def get_token(self):
        (d, c) = self.get_dvs_context(user_ref=False)
        encoded = urllib.urlencode({'data': json.dumps(d), 'context' : json.dumps(c)})
        tokenUrl = self.VIDEO_TOKEN + '?' + encoded
        result = {}
        try:
            data = requests.get(tokenUrl, headers=self.headers).json()
            return data
        except:
            pass
        return result
        
    def get_data(self, url):
        result = None
        try:
            data = requests.get(url, headers=self.headers, allow_redirects=True).text
            return data
        except:
            pass
        return result