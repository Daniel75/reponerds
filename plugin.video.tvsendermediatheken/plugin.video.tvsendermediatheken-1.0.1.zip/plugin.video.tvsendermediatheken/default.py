#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,xbmcplugin,xbmcgui,urllib,sys,re,os

addon = xbmcaddon.Addon()
pluginhandle = int(sys.argv[1])
addonID = addon.getAddonInfo('id')
iconPath = 'rescources/Media/'
iconPro7=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'pro7.png')
iconSat1=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'sat1.png')
iconKabel1=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'kabel1.png')
iconSIXX=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'sixx.png')
iconSat1Gold=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'sat1gold.png')
iconProSiebenMAXX=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'prosiebenmaxx.png')
iconZDFNeo=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'zdfneo.png')
iconZDFKultur=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'zdfkultur.png')
iconZDFInfo=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'zdfinfo.png')
iconArte=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'arte.png')
iconKikaninchen=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'kikaninchen.png')
iconNickelodeon=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'nickelodeon.png')
iconNickJr=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'nickjr.png')
iconNickNight=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'nicknight.png')
iconORF=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'orf.png')
iconTLC=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'TLC.png')
iconMTV=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'mtv.png')
iconZDF=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'zdf.png')
iconARD=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'ard.png')
iconDMAX=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'dmax.png')
iconKIKA=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'kika.png')
iconTELE5=xbmc.translatePath('special://home/addons/'+addonID+'/'+iconPath+'tele5.png')
fanartNO=xbmc.translatePath('')

def index():
    xbmcplugin.addSortMethod(pluginhandle, xbmcplugin.SORT_METHOD_LABEL)
    addDir("ProSieben","plugin://plugin.video.7tv/pro7/library/",iconPro7,fanartNO)
    addDir("Sat1","plugin://plugin.video.7tv/sat1/library/",iconSat1,fanartNO)
    addDir("Kabel1","plugin://plugin.video.7tv/kabel1/library/",iconKabel1,fanartNO)
    addDir("SIXX","plugin://plugin.video.7tv/sixx/library/",iconSIXX,fanartNO)
    addDir("Sat1 Gold","plugin://plugin.video.7tv/sat1gold/library/",iconSat1Gold,fanartNO)
    addDir("ProSieben MAXX","plugin://plugin.video.7tv/prosiebenmaxx/library/",iconProSiebenMAXX,fanartNO)
    addDir("ZDF Neo","plugin://plugin.video.zdf_de_lite/?mode=listShows&url=http%3a%2f%2fwww.zdf.de%2fZDFmediathek%2fsenderstartseite%2fsst1%2f1209122",iconZDFNeo,fanartNO)
    addDir("ZDF Kultur","plugin://plugin.video.zdf_de_lite/?mode=listShows&url=http%3a%2f%2fwww.zdf.de%2fZDFmediathek%2fsenderstartseite%2fsst1%2f1317640",iconZDFKultur,fanartNO)
    addDir("ZDF Info","plugin://plugin.video.zdf_de_lite/?mode=listShows&url=http%3a%2f%2fwww.zdf.de%2fZDFmediathek%2fsenderstartseite%2fsst1%2f1209120",iconZDFInfo,fanartNO)
    addDir("Arte","plugin://plugin.video.arte_tv/?mode=list-clusters",iconArte,fanartNO)
    addDir("Kikaninchen","plugin://plugin.video.kikaninchen/",iconKikaninchen,fanartNO)
    addDir("MTV","plugin://plugin.video.mtv_de/?mode=listShows&url=http%3a%2f%2fwww.mtv.de%2fshows%2fasync_data.json%3fsort%3dplayable",iconMTV,fanartNO)
    addDir("Nickelodeon","plugin://plugin.video.nick_de/?mode=listShows&url=http%3a%2f%2fwww.nick.de%2fvideos",iconNickelodeon,fanartNO)
    addDir("Nick Jr.","plugin://plugin.video.nick_de/?mode=listShowsJR&url=http%3a%2f%2fwww.nickjr.de%2fvideos",iconNickJr,fanartNO)
    addDir("Nick Night","plugin://plugin.video.nick_de/?mode=listShowsNight&url=http%3a%2f%2fwww.nicknight.de",iconNickNight,fanartNO)
    addDir("ORF","plugin://plugin.video.orftvthek4de/?backdrop=C%3a%5cUsers%5cSteffen%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.orftvthek4de%5cresources%5cmedia%5cfanart_top.png&banner=C%3a%5cUsers%5cSteffen%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.orftvthek4de%5cresources%5cmedia%5cshows_banner.jpg&link&mode=getSendungen&title=Sendungen",iconORF,fanartNO)
    addDir("TLC","plugin://plugin.video.tlc_de/?action=showLibrary",iconTLC,fanartNO)
    addDir("ZDF","plugin://plugin.video.zdf_de_lite/','74','?mode=listAZ&url",iconZDF,fanartNO)
    addDir("ARD","plugin://plugin.video.ardmediathek_de/','65','?mode=listShowsAZMain&url",iconARD,fanartNO)
    addDir("DMAX","plugin://plugin.video.dmax_de/','68','?mode=listAZ&thumb=C%3a%5cUsers%5cSteffen%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.dmax_de%5cicon.png&title&url",iconDMAX,fanartNO)
    addDir("KIKA","plugin://plugin.video.kika_de/','71','?audioUrl&mode=listShowsAZ&url",iconKIKA,fanartNO)
    addDir("TELE5","plugin://plugin.video.tele5_de/','71','?audioUrl&mode=listShowsAZ&url",iconTELE5,fanartNO)
    xbmcplugin.endOfDirectory(pluginhandle)


def addDir(name,url,iconimage,fanartimage):
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image',fanartimage)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    return ok


def translation(id):
    return addon.getLocalizedString(id).encode('utf-8')


def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

index()
