README - some notes

1. If you want to exclude numbers from monitoring enter
   these numbers (only numbers, no spaces or special chars
   within are allowed) separated by comma and/or space in the
   provided field. Leave this field blank if you don't want to
   exclude any number.

   Example: 08154711, 08154712
   
2. Some Boxes need a user and a password for login, others need
   only password. Leave username blank if you don't need this.