# -*- coding: utf-8 -*-

import re

def get_menu_items(data):
    items = []
    
    items.append({'mode':'live', 'title':'Live'})
    menu_items = data['menu_items']
    
    sport_channel = menu_items[5]['Sport Channel']
    for i in sport_channel:
        title = i['title'].encode('utf-8')
        content_key = i['content_key']
        items.append({'mode':'sub_menu', 'title':title, 'id':content_key})
        
    partner_channels = menu_items[4]['Partner Channel']
    for x in partner_channels:
        title = x['title'].encode('utf-8')
        content_key = x['content_key']
        image = x['icon']
        items.append({'mode':'videos', 'title':title, 'id':content_key, 'image':image})
    return items

def get_sub_menu_items(data,channel):
    items = []
    menu_items = data['menu_items']
    
    sport_channel = menu_items[5]['Sport Channel']
    for i in sport_channel:
        __title__ = i['title'].encode('utf-8')
        if channel == __title__:
            submenu = i['submenu']
            for x in submenu:
                title = x['title'].encode('utf-8')
                content_key = x['content_key']
                image = x['icon']
                items.append({'mode':'videos', 'title':title, 'id':content_key, 'image':image})
    return items
    
def get_stageid(data,ck):
    id = None
    content = data['content']
    contentPage = str(content[ck]['contentPage'])
    r = re.search("u'stageid': u'(\d+)'", contentPage)
    if r:
        id = r.group(1)
    return id

def get_live_items(data):
    items = []
    videos = data.get('video', None)
    if videos:
        for i in videos:
            a = i['@attributes']
            id = a['id']
            islive = a['islive']
            start = a['scheduled_start'][:16]
            end = a['scheduled_end'][:16]
            title = i['titleEN']
            liga = i['liga']
            sport = i['sport']
            description = unicode('Start: %s\nEnd: %s\nSport: %s\nLiga: %s' % (start,end,sport,liga)).encode('utf-8')
            if islive == 'true':
                name = unicode('[COLOR red]LIVE[/COLOR] - %s' % (title)).encode('utf-8')
            else:
                name = unicode('%s %s' % (start,title)).encode('utf-8')
            image = 'http://images.laola1.tv/%s_396x223.jpg' % id #i['image_ios']
            items.append({'mode':'play', 'live':'true', 'title':name, 'id':id, 'description':description, 'image':image})
    return items

def get_video_items(data):
    items = []
    videos = data.get('VIDEO', None)
    if videos:
        for i in videos:
            a = i['@attributes']
            title = i['TITLE']
            description = i['DESCRIPTION']
            if description:
                description = description.encode('utf-8')
            id = a['ID']
            start = a['scheduled_start'][:16]
            image = 'http://images.laola1.tv/%s_396x223.jpg' % id #i['IMAGE_169']
            name = unicode('%s (%s)' % (title,start)).encode('utf-8')
            items.append({'mode':'play', 'live':'false', 'title':name, 'id':id, 'description':description, 'image':image})
    return items

def get_unas_url(data):
    item = None
    status = data['status']
    if status == 'success':
        url = data['data']['stream-access'][0]
        return status,url
    else:
        message = data['message']
        return message,item

def get_master(data,q):
    y = ['350','750','1000','1500','6000']
    z = y[q]
    item = None
    a = re.search('auth="(.*?)"', data)
    b = re.search('url="(http.*?)"', data)
    c = re.search('comment="(.*?)"', data)
    if a and b:
        auth = a.group(1)
        url = b.group(1)
        master = '%s?hdnea=%s&b=0-%s' % (url,auth,z)
        return master
    elif c:
        comment = c.group(1)
        return comment
    else:
        return item

def is_premium(data):
    result = 'Login Failed'
    if data:
        if data.get('error', None):
            return data['error'][0]
        elif data.get('result', None):
            return data['result']['premium']
    return result

def create_cookie(data):
    result = None
    if data:
        premium = re.search('premium=(.*?);', data)
        email   = re.search('email=(.*?);', data)
        session = re.search('session=(.*?);', data)
        akaau   = re.search('akaau=(.*?);', data)
        if premium and email and session and akaau:
            cookie = 'premium=%s; email=%s; session=%s; akaau=%s' % (premium.group(1),email.group(1),session.group(1),akaau.group(1))
            return cookie
    return result