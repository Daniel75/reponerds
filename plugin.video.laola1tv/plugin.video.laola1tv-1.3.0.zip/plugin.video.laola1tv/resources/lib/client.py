# -*- coding: utf-8 -*-

import simple_requests as requests

class Client(object):

    def __init__(self, portal, language, email, password, cookie):
        self.headers    = {
                            'User-Agent':  'Kodi',
                            'Referer'   :  'http://www.laola1.tv'
                            }
                            
        self.v2         = 'https://club.laola1.tv/sp/laola1tv/api/v2/'
        self.v3         = 'https://club.laola1.tv/sp/laola1tv/api/v3/'
        self.feed       = 'http://www.laola1.tv/feed/'
        
        languages       = ['de','en','ru']
        portals         = ['at','de','int','ru','cis']
        
        self.partner    = '22'
        self.target     = '2'
        
        self.__lang__     = languages[int(language)]
        self.__portal__   = portals[int(portal)]
        self.__email__    = email
        self.__password__ = password
        self.__cookie__   = cookie
        
        self.portal     = self.get_portal()

    def get_content(self,type):
        result = {}
        try:
            url = self.feed + 'appfeed.php'
            params = {
                        'type':type,
                        'target':'8',
                        'customer':'1001',
                        'lang':self.__lang__,
                        'portal':self.portal
                        }
            data = requests.get(url, headers=self.headers, params=params).json()
            return data
        except:
            pass
        return result
        
    def get_videos(self,id):
        result = {}
        try:
            url = self.feed + 'app_video.feed.php'
            params = {
                        'targetID':'8',
                        'template':'3',
                        'v':'2',
                        'partner':self.partner,
                        'stageID':id,
                        'page':'0',
                        'rows':'27',
                        'lang':self.__lang__,
                        'portal':self.portal,
                        'format':'json'
                        }
            data = requests.get(url, headers=self.headers, params=params).json()
            return data
        except:
            pass
        return result
        
    def get_live_feed(self):
        result = {}
        try:
            url = self.feed + 'app_video.feed.php'
            params = {
                        'targetID':'17',
                        'order':'asc',
                        'partner':self.partner,
                        'lang':self.__lang__,
                        'geo':self.portal,
                        'records':'100',
                        'format':'json'
                        }
            data = requests.get(url, headers=self.headers, params=params).json()
            return data
        except:
            pass
        return result
            
    def get_player(self,id,live):
        result = {}
        try:
            if live == 'true':
                self.target = '17'
            url = self.v3 + 'user/session/premium/player/stream-access'
            self.headers.update({'cookie':self.__cookie__})
            form_data   = {'0' : 'tv.laola1.laolatv.premiumclub',
                            '1': 'tv.laola1.laolatv.premiumclub_all_access'}
            params      = {'videoId': id,
                            'label' : 'laola1tv',
                            'area'  : 'laola1tv',
                            'target': self.target}
            data        = requests.post(url, headers=self.headers, data=form_data, params=params).json()
            return data
        except:
            pass
        return result
            
    def get_unas_xml(self,id):
        result = []
        try:
            url = id + '&format=iphone'
            data = requests.get(url, headers=self.headers).text
            return data
        except:
            pass
        return result
            
    def get_portal(self):
        result = 'int'
        try:
            url = 'http://www.laola1.tv/%s-%s/usergeo' % (self.__lang__,self.__portal__)
            data = requests.get(url, headers=self.headers).json()
            portal = data['portal']
            return portal
        except:
            pass
        return result
        
    def login(self):
        result = {}
        try:
            if self.__email__ and self.__password__:
                url = self.v2 + 'session'
                data = {'e':self.__email__, 'p':self.__password__}
                r = requests.post(url, headers=self.headers, data=data)
                cookie = r.headers.get('set-cookie')
                return cookie
        except:
            pass
        return result
        
    def logout(self):
        try:
            if self.__cookie__:
                url = self.v2 + 'session/delete'
                self.headers.update({'cookie':self.__cookie__})
                r = requests.post(url, headers=self.headers)
        except:
            pass

    def deletesession(self):
        try:
            if self.__cookie__:
                url = self.v3 + 'user/session/premium/delete'
                self.headers.update({'cookie':self.__cookie__})
                r = requests.post(url, headers=self.headers)
        except:
            pass

    def subscription(self,cookie):
        result = {}
        try:
            url = self.v2 + 'user'
            self.headers.update({'cookie':cookie})
            data = requests.get(url, headers=self.headers).json()
            return data
        except:
            pass
        return result