# -*- coding: utf-8 -*-

import os,re,sys,urllib,urlparse
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs

addon = xbmcaddon.Addon()
home = addon.getAddonInfo('path').decode('utf-8')
iconimage = xbmc.translatePath(os.path.join(home, 'icon.png'))
pluginhandle = int(sys.argv[1])

__quality__  = addon.getSetting('quality')
__portal__   = addon.getSetting('portal')
__language__ = addon.getSetting('lang')
__email__    = addon.getSetting('email').encode('utf-8')
__password__ = addon.getSetting('password').encode('utf-8')
__cookie__   = addon.getSetting('cookie')

from resources.lib.client import Client
from resources.lib import helper

client = Client(__portal__, __language__, __email__, __password__, __cookie__)

def menu():
    type = 'menu'
    data = client.get_content(type)
    if data:
        items = helper.get_menu_items(data)
        for i in items:
            add_dir(i)
    xbmcplugin.endOfDirectory(pluginhandle)
    login()

def sub_menu():
    type = 'menu'
    data = client.get_content(type)
    if data:
        title = args['title'][0]
        items = helper.get_sub_menu_items(data,title)
        for i in items:
            add_dir(i)
    xbmcplugin.endOfDirectory(pluginhandle)

def live():
    data = client.get_live_feed()
    if data:
        items = helper.get_live_items(data)
        for i in items:
            add_video(i)
    xbmcplugin.endOfDirectory(pluginhandle)

def videos():
    ck = args['id'][0]
    type = 'content'
    content = client.get_content(type)
    id = helper.get_stageid(content,ck)
    data = client.get_videos(id)
    if data:
        items = helper.get_video_items(data)
        for i in items:
            add_video(i)
    xbmcplugin.endOfDirectory(pluginhandle)

def play():
    id = args['id'][0]
    live = args['live'][0]
    q = int(__quality__)
    data = client.get_player(id,live)
    if data:
        status,url = helper.get_unas_url(data)
        if url:
            xml = client.get_unas_xml(url)
            if xml:
                path = helper.get_master(xml,q)
                if path.startswith('http') and 'm3u8' in path:
                    listitem = xbmcgui.ListItem(path=path)
                    xbmcplugin.setResolvedUrl(pluginhandle, True, listitem)
                elif path:
                    xbmc.executebuiltin(unicode('Notification(%s,'',4000,%s)' % (path,iconimage)).encode('utf-8'))
            else:
                xbmc.executebuiltin('Notification(%s,'',4000,%s)' % ('Stream Not Available',iconimage))
        else:
            xbmc.executebuiltin('Notification(%s,'',4000,%s)' % (status,iconimage))
    client.deletesession()

def login():
    client.logout()
    login_data = client.login()
    cookie = helper.create_cookie(login_data)
    addon.setSetting('cookie',cookie)

def subscription():
    user_data = client.subscription(__cookie__)
    result = helper.is_premium(user_data)
    if result == True:
        return result
    else:
        if result == False:
            result = 'Login Successful!\nPlease update your Subscription in order to get access to this content!'
        else:
            result = 'Login Failed!\n%s' % (str(result).encode('utf-8'))
        dialog = xbmcgui.Dialog()
        dialog.ok('Login Message', result)
    return result
        
def add_dir(item):
    u = build_url({'mode':item['mode'], 'title':item['title'], 'id':item.get('id', '')})
    item=xbmcgui.ListItem(item['title'], iconImage="DefaultFolder.png", thumbnailImage=item.get('image', iconimage))
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item,isFolder=True)
    
def add_video(item):
    title = item['title']
    id = item['id']
    image = item.get('image', iconimage)
    plot = item['description']
    live = item['live']
    u = build_url({'mode': item['mode'], 'live':live, 'title':title, 'id':id})
    item=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=image)
    item.setInfo(type='Video', infoLabels={'Title':title, 'Plot':plot})
    #item.addStreamInfo('video', {'duration':duration})
    item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(pluginhandle,url=u,listitem=item)

def build_url(query):
    return sys.argv[0] + '?' + urllib.urlencode(query)

args = urlparse.parse_qs(sys.argv[2][1:])
mode = args.get('mode', None)
xbmc.log('Arguments: '+str(args), level=1)

if mode==None:
    if __email__ and __password__:
        menu()
    else:
        addon.openSettings() 
else:
    exec '%s()' % mode[0]